package com.example.utari.peserta;

interface BuatBiodata {
}
